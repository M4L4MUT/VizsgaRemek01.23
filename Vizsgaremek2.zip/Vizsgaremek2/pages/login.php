<?php
if (filter_input(INPUT_POST, 'login', FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE)) {
        $myusername = $_POST['myusername'];
        $mypassword = $_POST['mypassword'];

}
?>

<div id="login">
    <div id="bg"></div>

    <form method="post" action="login.php">
        <div class="form-field">
            <input type="text" name="myusername" placeholder="Felhasználónév" required/>
        </div>

        <div class="form-field">
            <input type="password" name="mypassword" placeholder="Jelszó" required/>
        </div>
        <a href="index.php?menu=register"><p>Még nem regisztráltál?</p></a>
        <div class="form-field">
            <button class="btn" type="submit" name="login" value="1">Bejelentkezés</button>
        </div>
        
    </form>

    
</div>